import { View, Text } from "react-native";
export default function ForgotPasswordScreen() {
  return (
    <View>
      <Text>ForgotPassword</Text>
    </View>
  );
}
