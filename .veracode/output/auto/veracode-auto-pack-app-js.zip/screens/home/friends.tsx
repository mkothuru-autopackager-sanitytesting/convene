import { View, Text } from "react-native";
export default function Friends() {
  return (
    <View>
      <Text>Friends</Text>
    </View>
  );
}
