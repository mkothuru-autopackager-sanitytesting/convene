//navigation
type RootStackParamList = {
  "auth-stack": undefined;
  "home-stack": undefined;
};
type AuthStackParamList = {
  login: undefined;
  signup: undefined;
  "forgot-password": undefined;
};
type HomeStackParamList = {
  home: undefined;
  "add-event": undefined;
  unsplash: undefined;
  settings: undefined;
};
